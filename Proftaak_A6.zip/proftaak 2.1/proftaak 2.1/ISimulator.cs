﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proftaak_2._1
{
    public interface ISimulator
    {

    }
}
