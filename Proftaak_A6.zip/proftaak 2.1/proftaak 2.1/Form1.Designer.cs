﻿namespace proftaak_2._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.speed = new System.Windows.Forms.Label();
            this.speedValue = new System.Windows.Forms.Label();
            this.distance = new System.Windows.Forms.Label();
            this.distanceValue = new System.Windows.Forms.Label();
            this.pulse = new System.Windows.Forms.Label();
            this.pulseValue = new System.Windows.Forms.Label();
            this.rpm = new System.Windows.Forms.Label();
            this.rpmValue = new System.Windows.Forms.Label();
            this.elapsedTime = new System.Windows.Forms.Label();
            this.elapsedTimeValue = new System.Windows.Forms.Label();
            this.energy = new System.Windows.Forms.Label();
            this.energyValue = new System.Windows.Forms.Label();
            this.requestedPower = new System.Windows.Forms.Label();
            this.requestedPowerValue = new System.Windows.Forms.Label();
            this.actualPower = new System.Windows.Forms.Label();
            this.actualPowerValue = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // speed
            // 
            this.speed.AutoSize = true;
            this.speed.Location = new System.Drawing.Point(40, 13);
            this.speed.Name = "speed";
            this.speed.Size = new System.Drawing.Size(36, 13);
            this.speed.TabIndex = 0;
            this.speed.Text = "speed";
            // 
            // speedValue
            // 
            this.speedValue.AutoSize = true;
            this.speedValue.Location = new System.Drawing.Point(136, 13);
            this.speedValue.Name = "speedValue";
            this.speedValue.Size = new System.Drawing.Size(63, 13);
            this.speedValue.TabIndex = 1;
            this.speedValue.Text = "speedValue";
            // 
            // distance
            // 
            this.distance.AutoSize = true;
            this.distance.Location = new System.Drawing.Point(40, 38);
            this.distance.Name = "distance";
            this.distance.Size = new System.Drawing.Size(47, 13);
            this.distance.TabIndex = 2;
            this.distance.Text = "distance";
            // 
            // distanceValue
            // 
            this.distanceValue.AutoSize = true;
            this.distanceValue.Location = new System.Drawing.Point(136, 38);
            this.distanceValue.Name = "distanceValue";
            this.distanceValue.Size = new System.Drawing.Size(74, 13);
            this.distanceValue.TabIndex = 3;
            this.distanceValue.Text = "distanceValue";
            // 
            // pulse
            // 
            this.pulse.AutoSize = true;
            this.pulse.Location = new System.Drawing.Point(40, 68);
            this.pulse.Name = "pulse";
            this.pulse.Size = new System.Drawing.Size(32, 13);
            this.pulse.TabIndex = 4;
            this.pulse.Text = "pulse";
            // 
            // pulseValue
            // 
            this.pulseValue.AutoSize = true;
            this.pulseValue.Location = new System.Drawing.Point(136, 68);
            this.pulseValue.Name = "pulseValue";
            this.pulseValue.Size = new System.Drawing.Size(59, 13);
            this.pulseValue.TabIndex = 5;
            this.pulseValue.Text = "pulseValue";
            // 
            // rpm
            // 
            this.rpm.AutoSize = true;
            this.rpm.Location = new System.Drawing.Point(40, 97);
            this.rpm.Name = "rpm";
            this.rpm.Size = new System.Drawing.Size(24, 13);
            this.rpm.TabIndex = 6;
            this.rpm.Text = "rpm";
            // 
            // rpmValue
            // 
            this.rpmValue.AutoSize = true;
            this.rpmValue.Location = new System.Drawing.Point(136, 97);
            this.rpmValue.Name = "rpmValue";
            this.rpmValue.Size = new System.Drawing.Size(51, 13);
            this.rpmValue.TabIndex = 7;
            this.rpmValue.Text = "rpmValue";
            // 
            // elapsedTime
            // 
            this.elapsedTime.AutoSize = true;
            this.elapsedTime.Location = new System.Drawing.Point(40, 126);
            this.elapsedTime.Name = "elapsedTime";
            this.elapsedTime.Size = new System.Drawing.Size(67, 13);
            this.elapsedTime.TabIndex = 8;
            this.elapsedTime.Text = "elapsedTime";
            // 
            // elapsedTimeValue
            // 
            this.elapsedTimeValue.AutoSize = true;
            this.elapsedTimeValue.Location = new System.Drawing.Point(136, 126);
            this.elapsedTimeValue.Name = "elapsedTimeValue";
            this.elapsedTimeValue.Size = new System.Drawing.Size(94, 13);
            this.elapsedTimeValue.TabIndex = 9;
            this.elapsedTimeValue.Text = "elapsedTimeValue";
            // 
            // energy
            // 
            this.energy.AutoSize = true;
            this.energy.Location = new System.Drawing.Point(40, 149);
            this.energy.Name = "energy";
            this.energy.Size = new System.Drawing.Size(39, 13);
            this.energy.TabIndex = 10;
            this.energy.Text = "energy";
            // 
            // energyValue
            // 
            this.energyValue.AutoSize = true;
            this.energyValue.Location = new System.Drawing.Point(136, 149);
            this.energyValue.Name = "energyValue";
            this.energyValue.Size = new System.Drawing.Size(66, 13);
            this.energyValue.TabIndex = 11;
            this.energyValue.Text = "energyValue";
            // 
            // requestedPower
            // 
            this.requestedPower.AutoSize = true;
            this.requestedPower.Location = new System.Drawing.Point(40, 177);
            this.requestedPower.Name = "requestedPower";
            this.requestedPower.Size = new System.Drawing.Size(84, 13);
            this.requestedPower.TabIndex = 12;
            this.requestedPower.Text = "requestedPower";
            // 
            // requestedPowerValue
            // 
            this.requestedPowerValue.AutoSize = true;
            this.requestedPowerValue.Location = new System.Drawing.Point(136, 177);
            this.requestedPowerValue.Name = "requestedPowerValue";
            this.requestedPowerValue.Size = new System.Drawing.Size(111, 13);
            this.requestedPowerValue.TabIndex = 13;
            this.requestedPowerValue.Text = "requestedPowerValue";
            // 
            // actualPower
            // 
            this.actualPower.AutoSize = true;
            this.actualPower.Location = new System.Drawing.Point(40, 206);
            this.actualPower.Name = "actualPower";
            this.actualPower.Size = new System.Drawing.Size(66, 13);
            this.actualPower.TabIndex = 14;
            this.actualPower.Text = "actualPower";
            // 
            // actualPowerValue
            // 
            this.actualPowerValue.AutoSize = true;
            this.actualPowerValue.Location = new System.Drawing.Point(136, 206);
            this.actualPowerValue.Name = "actualPowerValue";
            this.actualPowerValue.Size = new System.Drawing.Size(93, 13);
            this.actualPowerValue.TabIndex = 15;
            this.actualPowerValue.Text = "actualPowerValue";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(315, 278);
            this.Controls.Add(this.actualPowerValue);
            this.Controls.Add(this.actualPower);
            this.Controls.Add(this.requestedPowerValue);
            this.Controls.Add(this.requestedPower);
            this.Controls.Add(this.energyValue);
            this.Controls.Add(this.energy);
            this.Controls.Add(this.elapsedTimeValue);
            this.Controls.Add(this.elapsedTime);
            this.Controls.Add(this.rpmValue);
            this.Controls.Add(this.rpm);
            this.Controls.Add(this.pulseValue);
            this.Controls.Add(this.pulse);
            this.Controls.Add(this.distanceValue);
            this.Controls.Add(this.distance);
            this.Controls.Add(this.speedValue);
            this.Controls.Add(this.speed);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

      
        private System.Windows.Forms.Label speed;
        private System.Windows.Forms.Label speedValue;
        private System.Windows.Forms.Label distance;
        private System.Windows.Forms.Label distanceValue;
        private System.Windows.Forms.Label pulse;
        private System.Windows.Forms.Label pulseValue;
        private System.Windows.Forms.Label rpm;
        private System.Windows.Forms.Label rpmValue;
        private System.Windows.Forms.Label elapsedTime;
        private System.Windows.Forms.Label elapsedTimeValue;
        private System.Windows.Forms.Label energy;
        private System.Windows.Forms.Label energyValue;
        private System.Windows.Forms.Label requestedPower;
        private System.Windows.Forms.Label requestedPowerValue;
        private System.Windows.Forms.Label actualPower;
        private System.Windows.Forms.Label actualPowerValue;

    }
}